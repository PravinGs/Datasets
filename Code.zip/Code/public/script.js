document.getElementById('uploadForm').addEventListener('submit', function (event) {
  event.preventDefault();
  document.getElementById('loader').style.display = 'block';
  let fileInput = document.getElementById('fileInput');
  let file = fileInput.files[0];
  let formData = new FormData();
  formData.append('file', file);

  fetch('http://localhost:8080/upload', {
    method: 'POST',
    body: formData
  })
    .then(response => response.json())
    .then(data => {
      document.getElementById('loader').style.display = 'none';
      document.getElementById('data').innerText = data.response.replace(/\*\*(.*?)\*\*/g, '$1');
    })
    .catch(error => {
      document.getElementById('loader').style.display = 'none';
      document.getElementById('data').innerText = 'Failed! Please, Try again later.';
      console.error('Error:', error);
    });
});