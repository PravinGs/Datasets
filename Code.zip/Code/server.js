import { GoogleGenerativeAI } from "@google/generative-ai";
import { configDotenv } from "dotenv";
import { fileURLToPath } from 'url';
import express from "express";
import path from "path";
import cors from "cors";
import bodyParser from 'body-parser';
import multer from 'multer';

configDotenv();

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.use(cors());

app.use(express.static(path.join(__dirname, 'public')));

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

const prompt = "Help me to do hematological analysis of blood report. Explain everything in details. Tell me the cure if any health issues.";


app.post('/upload', upload.single('file'), async (request, response) => {
    const data = {
        inlineData: {
            data: Buffer.from(request.file.buffer).toString("base64"),
            mimeType: request.file.mimetype,
        },
    };
    
    const result = await model.generateContent([prompt, data]);
    response.status(200).send({response: result.response.text()})
})

app.get('/', (req, res) => { res.sendFile(path.join(__dirname, 'public', 'index.html')); });

app.listen(8080, () => { console.log(`Server is running at http://localhost:8080`); });
